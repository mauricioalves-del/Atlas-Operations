# QA — slide "Pacote de Baixas — Investimento Operacional"

Registro das correções de layout feitas durante a inspeção visual (render
slide a slide via LibreOffice/pdftoppm) antes da entrega.

## 1ª renderização — achados e correções

- **Cartões sobrepondo o subtítulo**: os 5 cartões de KPI estavam em y=1,16,
  invadindo a caixa do subtítulo do cabeçalho padrão (que vai até y=1,45).
  Corrigido movendo para y=1,55 (mesmo padrão já usado em
  `_slide_baixas_operacionais_externo`).
- **Mês cru no eixo** ("2026-07" em vez de "jul/26"): corrigido convertendo
  os meses pelo mesmo mapa `_MESES_PT_ABREV` usado no resto do MBR.
- **Nome de produto truncado em 38 caracteres**: com 4 tabelas lado a lado,
  texto demais pra largura disponível, sempre quebrando em 2 linhas.
  Reduzido para 26.

## 2ª renderização — achados e correções

- **Rótulo do total da tendência mensal quebrando em 2 linhas** ("R$" /
  "2.746"): a caixa de rótulo de uma série de linha (técnica usada pro
  "total empilhado") é mais estreita que a de um rótulo de barra comum —
  corrigido reduzindo a fonte desse rótulo especificamente (9,5pt → 7pt).
- **Coluna SKU quebrando em 2 linhas** para códigos numéricos de 10
  dígitos, e nome de produto ainda cortando no meio da palavra mesmo em 26
  caracteres: corrigido realocando a largura relativa das 3 colunas da
  tabela (SKU 0,9→1,2 / Produto 1,7→1,3 / Valor 0,9→1,0), reduzindo a
  truncagem do nome pra 20 caracteres, e reduzindo a margem interna da
  célula (0,04in em vez do padrão ~0,1in do python-pptx).
- **Rótulo de valor da barra "Valor por Motivo" quebrando em 2 linhas**
  ("R$" / "5.257") mesmo após reduzir a fonte (9pt → 8pt) e dar folga no
  eixo de valor (+22% acima do maior valor): isolado em teste à parte que a
  causa real não era largura nem fonte, e sim a ALTURA do gráfico — abaixo
  de ~1,3in de altura, o rótulo de ponta de barra horizontal (OUTSIDE_END)
  é forçado a quebrar em 2 linhas, com qualquer largura disponível à
  direita da barra. Corrigido aumentando a altura reservada pra esse
  widget (1,42in → 1,58in), compensada reduzindo em 0,08in a altura do
  gráfico de tendência logo acima (1,38in → 1,30in — folga suficiente, é um
  gráfico simples de 1 coluna por mês).

## 3ª renderização — confirmação

Todos os itens acima confirmados corrigidos: nenhum rótulo quebrando linha,
nenhuma célula de tabela com texto cortado no meio de forma estranha,
cartões/gráficos/tabelas sem sobreposição, rodapé ("Fonte: ...") sem
colidir com a tabela acima.

Um item investigado e descartado como falso positivo: os rótulos da rosca
"Cortesia — Área que Solicitou" pareciam cortados em baixa resolução (ex.
"R$ 11" em vez de "R$ 113"). Conferido em zoom e contra os valores brutos
do extrator (113,21 + 85,87 + 63,39 + 61,12 + 57,03 = 380,63, batendo com o
cartão "Cortesia") — os valores estão corretos e completos; o que parecia
corte era só o texto do rótulo ultrapassando visualmente o anel fino da
fatia (comportamento normal de rótulo central em fatia estreita de rosca,
não um bug).

## Estados de indisponibilidade testados

- **Não enviado**: mensagem "Pacote de Baixas - Investimento Operacional
  ainda não enviado" — OK.
- **Erro de leitura do arquivo** (HTML sem o JSON embutido esperado):
  mensagem "Não foi possível ler o Pacote de Baixas - Investimento
  Operacional" — OK.
- **Enviado, mas sem lançamentos no mês do relatório**: mensagem "Sem
  lançamentos até [mês]" — OK.

## Ferramentas usadas

- `python3 -c "import ast; ast.parse(...)"` — sintaxe dos 2 arquivos.
- `scripts/office/validate.py` — estrutura do `.pptx` gerado.
- `scripts/office/soffice.py --convert-to pdf` + `pdftoppm` — renderização
  para inspeção visual.
- `markitdown` — conferência do conteúdo textual/numérico de cada slide.
