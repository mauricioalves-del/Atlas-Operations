# atlas_fix_mbr_investimento_operacional.zip — Pacote de Baixas: Investimento Operacional no MBR

Data: 06/10/2026

## O que este pacote faz

Adiciona ao MBR um slide dedicado para o indicador **"Pacote de Baixas -
Investimento Operacional"**, reunindo os 4 motivos juntos (Cortesia,
Degustação, Sensorial/Inovações e Uso e Consumo) num único slide, com:

- 5 cartões no topo: Total investido no período + 1 cartão por motivo
  (valor e nº de lançamentos).
- Gráfico de tendência mensal (colunas empilhadas por motivo), com rótulo de
  dado mostrando só o **total geral por mês** (não por motivo).
- 3 indicadores lado a lado: barra "Valor por Motivo", rosca "Cortesia —
  Área que Solicitou" (com rótulo de valor em cada fatia) e funil
  "Degustação — Operação".
- Top 3 produtos por motivo (4 tabelinhas lado a lado).

Isso segue o pedido do Maurício (conversa de 06/10/2026) e a simulação de
layout aprovada antes desta implementação ("Aprovado").

## Por que precisou de um extrator novo (não é só um slide)

Esse indicador é um daqueles dashboards que renderizam TUDO (KPIs, gráficos
e tabelas) via JavaScript a partir de um JSON embutido no próprio HTML —
igual já acontecia com "Dispersão de Ficha Técnica" e "Metas Individuais".
A extração genérica que o MBR usa por padrão só lê `<table>` já prontas no
HTML, e para esse arquivo elas vêm vazias (preenchidas só em tempo de
execução no navegador) — então, sem um extrator dedicado, o slide apareceria
como "Sem tabelas encontradas", mesmo com o arquivo certo enviado.

Por isso este pacote inclui uma função nova,
`extrair_investimento_operacional`, que lê o JSON embutido direto e
reproduz em Python as mesmas contas que o próprio arquivo faz em
JavaScript — validada rodando contra o arquivo real que o Maurício enviou
(bateu com os valores mostrados nos prints: R$ 8.671,26 total, 436
lançamentos, etc.).

## Arquivos neste pacote

- `app/mbr_generator.py`
- `app/dashboards_externos_extrator.py`

Ambos substituem os arquivos de mesmo nome em `backend/app/` no projeto do
Atlas. Nenhum outro arquivo do backend precisa mudar.

## Passo a passo do deploy no Render

O Atlas roda no Render e é implantado por **upload manual de zip + redeploy**
— não por sincronização automática do GitHub, e não por editar a pasta
local do computador. Enviar os arquivos só pelo chat, ou só salvá-los na
pasta `C:\Users\mauri\Desktop\Atlas\Atlas\backend\app\`, não é suficiente
para a mudança valer no site em produção.

1. Baixe este zip (`atlas_fix_mbr_investimento_operacional.zip`) e extraia
   em uma pasta no seu computador.
2. Copie os 2 arquivos extraídos (`app/mbr_generator.py` e
   `app/dashboards_externos_extrator.py`) para dentro da pasta `backend/app/`
   do seu projeto Atlas, substituindo os arquivos existentes.
3. Gere um novo zip do projeto Atlas completo (a mesma forma que você já
   usou nas entregas anteriores, ex. `atlas-v19.zip`) com os 2 arquivos já
   substituídos.
4. No painel do Render, abra o serviço do backend do Atlas e faça o deploy
   desse novo zip (o mesmo caminho usado nas correções anteriores — Manual
   Deploy / upload do pacote).
5. Aguarde o serviço reiniciar (o próprio Render mostra o status do deploy).
6. Gere o MBR de novo pelo site e confira o novo slide "Pacote de Baixas —
   Investimento Operacional".

## O que confirmar depois do deploy

- Confira se o nome cadastrado do indicador em **Auditoria > Outros
  Dashboards** está exatamente como **"Pacote de baixas - Investimento
  Operacional"** (a busca ignora acento/maiúscula/espaço duplo, mas um nome
  bem diferente não vai casar e o slide vai aparecer como "ainda não
  enviado").
- Se o arquivo `.html` desse indicador ainda não foi enviado nessa tela, o
  slide aparece com o aviso "Pacote de Baixas - Investimento Operacional
  ainda não enviado" — é o comportamento esperado, não é erro.
- Confira o slide completo com os dados reais do mês fechado (este pacote
  foi validado com os dados de teste de jul-set/2026 — ver `QA.md` para o
  que foi verificado visualmente).

## Validação feita (antes de empacotar)

- Sintaxe dos 2 arquivos (`ast.parse`) — sem erro.
- `scripts/office/validate.py` no `.pptx` de teste — todas as validações
  passaram.
- Extrator rodado direto contra o arquivo real enviado pelo Maurício —
  valores batendo com os prints mostrados.
- Inspeção visual do slide renderizado (conversão para imagem), com dado
  real e com os 3 estados de indisponibilidade (não enviado / erro de
  leitura / sem lançamentos no mês) — ver `QA.md` para o detalhe de cada
  correção de layout feita nessa inspeção.
